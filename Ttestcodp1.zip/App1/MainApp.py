# -*- coding: utf-8 -*-
"""
Created on Sun Sep  6 11:04:54 2020

@author: mmarcavage
"""

#Custom Classes
import Code.MDM_Util as mdmUtil
import Code.LogMe as logMe

#Logging
logMe.log_setup()
logMe.logging.info('Application Started')


num1 = 20
num2 = 10

print("\n add : ", mdmUtil.add(num1,num2))
print("\n sub : ", mdmUtil.sub(num1,num2))
print("\n mul : ", mdmUtil.mul(num1,num2))



#Logging
logMe.logging.info('Application Finished')