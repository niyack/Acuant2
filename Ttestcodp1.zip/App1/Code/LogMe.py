# -*- coding: utf-8 -*-
"""
Created on Sun Sep  6 11:10:58 2020

@author: mmarcavage
"""

import time
import logging
import logging.handlers

def log_setup():
    log_handler = logging.handlers.WatchedFileHandler('./Logs/App1.log')
    formatter = logging.Formatter('%(asctime)s MDM_App1 [%(process)d]: %(message)s','%b %d %H:%M:%S')
    formatter.converter = time.gmtime  # if you want UTC time
    log_handler.setFormatter(formatter)
    logger = logging.getLogger()
    logger.addHandler(log_handler)
    logger.setLevel(logging.DEBUG)







#log_setup()
#logging.info('Hello, World!')

#import os
#os.rename('my.log', 'my.log-old')
#logging.info('Hello, New World!')