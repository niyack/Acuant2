# -*- coding: utf-8 -*-
"""
Created on Sun Sep  6 11:02:45 2020

@author: mmarcavage
"""

def add(arg1, arg2):
    return arg1 + arg2

def sub(arg1, arg2) :
    return arg1 - arg2

def mul(arg1, arg2) :
    return arg1 * arg2